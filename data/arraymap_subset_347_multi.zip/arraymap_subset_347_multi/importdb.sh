mongoimport --db test1--collection biosamples --drop --file ./biosamples.json --jsonArray
mongoimport --db test1--collection individuals --drop --file ./individuals.json --jsonArray
mongoimport --db test1--collection callsets_grch36 --drop --file ./callsets_grch36.json --jsonArray
mongoimport --db test1--collection callsets_grch37 --drop --file ./callsets_grch37.json --jsonArray
mongoimport --db test1--collection callsets_grch38 --drop --file ./callsets_grch38.json --jsonArray
mongoimport --db test1--collection variants_cnv_grch36 --drop --file ./variants_cnv_grch36.json --jsonArray
mongoimport --db test1--collection variants_cnv_grch37 --drop --file ./variants_cnv_grch37.json --jsonArray
mongoimport --db test1--collection variants_cnv_grch38 --drop --file ./variants_cnv_grch38.json --jsonArray